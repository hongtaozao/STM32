/**
 * @file   digitron.h
 * @brief  digitron驱动程序
 * @version 
 * @date 2018-03-18
 */
 
#ifndef __DEGITRON_H
#define __DEGITRON_H

#include "stm32f0xx_hal.h"              // Keil.Standalone::Device:STM32Cube HAL:COMMON

enum 
{
  CHAR_NULL = 10, CHAR_DEC, CHAR_S, CHAR_N, CHAR_H, 
};

#define	DOT_0			0x01	
#define	DOT_1			0x02	
#define	DOT_2			0x04	
#define	DOT_3			0x08	
#define	DOT_4			0x10
#define	DOT_5			0x20
#define	DOT_6			0x40
#define	DOT_7		  0x80

#define	DOT_ALL	  0xFF

struct GPIO
{
	GPIO_TypeDef    *port;
	uint16_t        pin;
};


void digitron_dynamic_display(void);
void digitron_put_buf( unsigned char numb, unsigned char dat);
void digitron_put_dot(unsigned char dot);
void digitron_put_data(unsigned char position, unsigned char len, unsigned int dat);
#endif 
