/**
 * @file   digitron.c
 * @brief  digitron驱动程序
 * @version  v1.0             v1.1          v1.2
 * @date     2018-03-18       2018-05-15    2018-05-16
 */

#include "digitron.h"

static void digitron_shut_all(void);
static void digitron_com(unsigned char numb);
static void digitron_data(unsigned char dat);

const struct GPIO gpio_data[8] =             /**< ★ 数据端引脚，移植时，需修改 */
{
	GPIOB, GPIO_PIN_0,
	GPIOB, GPIO_PIN_1,
	GPIOB, GPIO_PIN_2,
	GPIOB, GPIO_PIN_3,
	GPIOB, GPIO_PIN_4,
  GPIOB, GPIO_PIN_5,
	GPIOB, GPIO_PIN_6,
	GPIOB, GPIO_PIN_7,
};

const struct GPIO gpio_com[] =               /**< ★ 公共端引脚，移植时，需修改 */
{
	GPIOC, GPIO_PIN_3,
  GPIOC, GPIO_PIN_2,
  GPIOC, GPIO_PIN_1,
  GPIOC, GPIO_PIN_0,
};
	

#define NUM_DIGITRONS (sizeof(gpio_com)/sizeof(struct GPIO))
  
  
static const unsigned char DIGITRON_MAP[] =		                
{
	0x3F,  0x06,  0x5B,  0x4F,  0x66,                 /**< 0 - 9 */ 
  0x6D,  0x7D,  0x07,  0x7F,  0x6F,
  0x00,  0x40,  0x64,  0x54,  0x74,  0x39,  0x76,                 /**< NULL - s n h C H  */
};


	
static unsigned char digitron_buf[NUM_DIGITRONS]; 		        /**< 显示缓冲区 */ 

/**
 *  @brief  动态显示
 *  @param  None
 *  @return None
 */
void digitron_dynamic_display(void)
{
	unsigned char i;
	for (i = 0; i < NUM_DIGITRONS; i++)
	{    
    digitron_shut_all();
    digitron_data(digitron_buf[i]);
    digitron_com(i);
		HAL_Delay(1);		 														
	}		
}

/**
 *  @brief  写数码管显示缓冲区
 *  @param  [in]numb 数码管序号
 *  @param  [in]dat 写入的数据
 *  @return None
 */
void digitron_put_buf( unsigned char numb, unsigned char dat)
{
	digitron_buf[numb] = DIGITRON_MAP[dat];	
}

/**
 *  @brief  写小数点
 *  @param  [in]numb 数码管序号
 *  @param  [in]dat 写入的数据
 *  @return None
 */
void digitron_put_dot(unsigned char dot)
{
	for(int i = 0; i < NUM_DIGITRONS; i++)
	{
		if(dot & (1 << i)) 
		{
			digitron_buf[i] += 0x80;        
		}        
	} 		
}

/**
 *  @brief  写数码管显示缓冲区
 *  @param  [in]position 起始位置
 *  @param  [in]len      数据位数
 *  @param  [in]dat      写入的数据
 *  @return None
 */
void digitron_put_data(unsigned char position, unsigned char len, unsigned int dat)
{
  unsigned int temp = dat;
  for(int i = position; i < position + len; i++)
  {
    digitron_buf[i] = DIGITRON_MAP[temp % 10];
    temp /= 10;    
  }	
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////
//内部函数

/**
 *  @brief  关闭所有数码管
 *  @param  None
 *  @return None
 */
static void digitron_shut_all(void)
{
  for(int i = 0; i < NUM_DIGITRONS; i++)
  {
    HAL_GPIO_WritePin(gpio_com[i].port, gpio_com[i].pin, GPIO_PIN_RESET);
  } 
}

/**
 *  @brief  打开某数码管
 *  @param  [in]numb  打开的数码管
 *  @return None
 */
static void digitron_com(unsigned char numb)
{ 
  HAL_GPIO_WritePin(gpio_com[numb].port, gpio_com[numb].pin, GPIO_PIN_SET);  
}

/**
 *  送数码管显示数据
 *  @param  [in]dat  显示的数据
 *  @return None
 */
static void digitron_data(unsigned char dat)
{
  for(int i = 0; i < 8; i++)
	{
		if(dat & (1 << i)) 
		{
			HAL_GPIO_WritePin(gpio_data[i].port, gpio_data[i].pin, GPIO_PIN_SET);        
		} 
    else
		{
			HAL_GPIO_WritePin(gpio_data[i].port, gpio_data[i].pin, GPIO_PIN_RESET);        
		}     
	}
}



