/**
  * @file   : ad_buffer.c
  * @brief  : adc������
  * @par    : none
  * @note   ����adc�������ݴ��뻺����
	*           �ײ���adc + dma
  * @History: 
  *  <data>    								 <version> 							   <author>    							<describe>
	* 2018/05/25 								  v0.1.0   							   ������					          adc������
  */


/** Includes ---------------------------------------------------------------------------------------------*/
#include "main.h"
#include "ad_buffer.h"
#include "adc.h"

#define ADC_BUFFER_SIZE   1024 		  /**< �� AD��������С */ 

static uint16_t adc_buffer[ADC_BUFFER_SIZE * ADC_CHANNEL_NUMB];

static void adc_dma_stop(void);

/** 
  * @brief :  ����ADC_DMAת��
  * @par   :	none
  * @note  :  none
  * @return:  none
  */
void adc_dma_start(void)
{
    HAL_ADC_Start_DMA(&hadc, (uint32_t *)&adc_buffer[0], ADC_BUFFER_SIZE * ADC_CHANNEL_NUMB);
}

/** 
  * @brief :	��ȡADֵ
  * @par   :	*p_sum  ADֵ�洢��ַ
  * @note  :  none
  * @return:  none
  */
void get_adc_value(uint16_t *p_ad)
{
  uint32_t ad_temp[ADC_CHANNEL_NUMB];
  
  adc_dma_stop();
  for(uint8_t j = 0; j < ADC_CHANNEL_NUMB; j++)
  {
    ad_temp[j] = 0UL;
    for(uint16_t i = 0; i < ADC_BUFFER_SIZE; i++)
    {      
      ad_temp[j] += adc_buffer[i * ADC_CHANNEL_NUMB + j];
    }	
    *(p_ad + j) = (uint16_t)(ad_temp[j] / ADC_BUFFER_SIZE);   
  }
  adc_dma_start();  
}



/** Private Function -------------------------------------------------------------------------------------*/
/** 
  * @brief :  �ر�ADC_DMAת��
  * @par   :	none
  * @note  : none
  * @return: none
  */
static void adc_dma_stop(void)
{
    HAL_ADC_Stop_DMA(&hadc);
}

/** End of file ------------------------------------------------------------------------------------------*/




