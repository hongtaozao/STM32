/** 
 *  @file       key.c
 *  @brief      ����CUBE�İ�����������(��ϵͳʱ��֧��)  
 *  @version    
 *  @date       2014-08-29 
 */
 
#include 	"key.h"

/** ���Ŷ��� */
static const struct GPIO_KEY key[] =                  /**< �� ѡ��GPIO���� */
{      
  GPIOA, GPIO_PIN_0, 
  GPIOC, GPIO_PIN_11,
  GPIOA, GPIO_PIN_15,
};

#define NUM_KEYS  sizeof(key) / sizeof(struct GPIO_KEY)
  
static enum KEY key_state = NO_PRESS;

/**
 *  ��ȡ����ֵ
 *  @param  None
 *  @return None
 */
void key_read(enum KEY *p_key_state)
{
  if(key_state >= SHORT_BASE_OFFSET)
  {
    *p_key_state = key_state;
    key_state    = NO_PRESS;
  }
  else
  {
    *p_key_state = NO_PRESS;
  }  
} 

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//�ص�����

void HAL_SYSTICK_Callback(void)
{
  static uint32_t last_tick = 0;
  static uint8_t key_numb = 0xff;
  
  switch(key_state)
  {
    case NO_PRESS:      
      for(int i = 0; i < NUM_KEYS; i++)
      {
        if(HAL_GPIO_ReadPin(key[i].port, key[i].pin) == 0) 
        {
          key_state = PRESS;
          last_tick = HAL_GetTick();          
          break;
        }             
      } 
      break;
    case PRESS:      
      for(int i = 0; i < NUM_KEYS; i++)
      {
        if(HAL_GPIO_ReadPin(key[i].port, key[i].pin) == 0) 
        {
          key_numb = i;          
          break;
        }
        if(i >= NUM_KEYS - 1)       /**< ���а�����û�а��� */
        { 
          key_state = PRESS_UP;  
        }         
      }
      break;      
    case PRESS_UP:      
      if((HAL_GetTick() - last_tick > SHORT_PRESS_DELAY)    && 
         (HAL_GetTick() - last_tick < LONG_PRESS_THRESHOLD)    )  
      {  
        key_state = (enum KEY)(SHORT_BASE_OFFSET + key_numb);  
      } 
      else if(HAL_GetTick() - last_tick >= LONG_PRESS_THRESHOLD)     
      {  
        key_state = (enum KEY)(LONG_BASE_OFFSET + key_numb);  
      }
      else     
      {  
        key_state = NO_PRESS;  
      }      
      break;
    default:
      break;
   }
}



