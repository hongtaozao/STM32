/**
 * @file   led.c
 * @brief  led驱动程序
 * @version 
 * @date 2014-03-19
 */

#include "led.h"

static void gpio_clock_enable(GPIO_TypeDef* GPIOx);

const struct LED led[] =
{
	GPIOA, GPIO_PIN_8,
	GPIOD, GPIO_PIN_2,
	GPIOC, GPIO_PIN_12,
};

#define NUM_LEDS (sizeof(led)/sizeof(struct LED))
	
/**
 * @brief  led配置 
 * @param  NONE
 */
void led_config(void) 
{
	for (uint8_t i = 0; i < NUM_LEDS; i++) 
	{
		/** 打开端口时钟 */        
		gpio_clock_enable(led[i].port);  

		/** 端口配置 */ 
		GPIO_InitTypeDef GPIO_InitStruct;
		GPIO_InitStruct.Pin   = led[i].pin;
		GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		GPIO_InitStruct.Pull  = GPIO_NOPULL;
		HAL_GPIO_Init(led[i].port, &GPIO_InitStruct);   
	}  
}

/**
 * @brief  点亮多个LED 
 * @param val 多个LED组合
 * 例如： led_on(LED_0 | LED_1)
 */
void led_on(uint16_t val) 
{
	uint8_t n;
	for(n = 0; n < NUM_LEDS; n++)
	{
		if (val & (1 << n)) 
		{
			HAL_GPIO_WritePin(led[n].port, led[n].pin, GPIO_PIN_RESET);        
		}        
	}    
}

/**
 * @brief  关闭多个LED 
 * @param val 多个LED组合
 * 例如： led_off(LED_0 | LED_1)
 */
void led_off(uint16_t val) 
{
	uint8_t n;
	for(n = 0; n < NUM_LEDS; n++)
	{
		if (val & (1 << n)) 
		{
			HAL_GPIO_WritePin(led[n].port, led[n].pin, GPIO_PIN_SET);        
		}        
	}     
}

/**
 * @brief  LED反转 
 * @param val 多个LED组合
 * 例如： led_toggle(LED_0 | LED_1)
 */
void led_toggle(uint16_t val) 
{
	for(uint8_t n = 0; n < NUM_LEDS; n++)
	{
		if (val & (1 << n)) 
		{
			HAL_GPIO_TogglePin(led[n].port, led[n].pin);        
		}        
	}     
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//内部函数

/**
 * @brief 打开某GPIO的端口时钟
 * @param GPIOx 某GPIO的端口时钟
 */
static void gpio_clock_enable(GPIO_TypeDef* GPIOx)
{       
	if (GPIOx == GPIOA)
	{
		__HAL_RCC_GPIOA_CLK_ENABLE();
	}
	else if (GPIOx == GPIOB)
	{
		__HAL_RCC_GPIOB_CLK_ENABLE();
	}
	else if (GPIOx == GPIOC)
	{
		__HAL_RCC_GPIOC_CLK_ENABLE();
	}
	else if (GPIOx == GPIOD)    
	{
		__HAL_RCC_GPIOD_CLK_ENABLE();
	}
}



