/** 
 *  @file       key.h
 *  @brief      ����CUBE�İ�����������(��ϵͳʱ��֧��)  
 *  @version    
 *  @date       2014-08-29 
 */
 
#ifndef	__KEY_H
#define	__KEY_H 

#include "stm32f0xx_hal.h"              // Keil.Standalone::Device:STM32Cube HAL:COMMON

#define SHORT_BASE_OFFSET     10                          
#define  LONG_BASE_OFFSET     20

#define SHORT_PRESS_DELAY      20
#define LONG_PRESS_THRESHOLD   1000

enum KEY                                                  /**< �� ����״̬ */
{
	NO_PRESS,   PRESS,    PRESS_UP, 
  KEY_WKUP_SHORT = SHORT_BASE_OFFSET, KEY_0_SHORT, KEY_1_SHORT,
  KEY_WKUP_LONG  = LONG_BASE_OFFSET,  KEY_0_LONG,  KEY_1_LONG, 
};


struct GPIO_KEY
{
  GPIO_TypeDef      *port;
  uint16_t          pin;
};


 
void key_read(enum KEY *p_key_state);

#endif
