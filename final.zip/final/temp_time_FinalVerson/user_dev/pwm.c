/**
 * @file   pwm.c
 * @brief  基于CUBE的pwm驱动程序
 * @author 王晓荣
 * @version 
 * @date 2019-04-09
 */

#include "pwm.h"

/**
 * @brief  启动PWM输出
 * @param  *htim   定时器
 * @param  Channel 通道
 */
void pwm_start(TIM_HandleTypeDef *htim, uint32_t Channel) 
{
	HAL_TIM_PWM_Start(htim, Channel);   
}

/**
 * @brief  停止PWM输出
 * @param  *htim   定时器
 * @param  Channel 通道
 */
void pwm_stop(TIM_HandleTypeDef *htim, uint32_t Channel) 
{
	HAL_TIM_PWM_Start(htim, Channel);   
}

/**
 * @brief  设置脉冲周期
 * @param  *htim   定时器
 * @param  Channel 通道
 * @param  period   脉冲周期（ms）
 */
void pwm_set_period(TIM_HandleTypeDef *htim, uint32_t Channel, uint16_t period) 
{
	__HAL_TIM_SET_AUTORELOAD(htim, period);   
}

/**
 * @brief  设置脉冲宽度
 * @param  *htim   定时器
 * @param  Channel 通道
 * @param  pulse   脉冲宽度（ms）
 */
void pwm_set_compare(TIM_HandleTypeDef *htim, uint32_t Channel, uint16_t pulse) 
{
	__HAL_TIM_SET_COMPARE(htim, Channel, pulse);   
}

/**
 * @brief  设置脉冲宽度和脉冲周期
 * @param  *htim   定时器
 * @param  Channel 通道
 * @param  pulse   脉冲宽度（ms）
 * @param  period  脉冲周期（ms）
 */
void pwm_set_compare_period(TIM_HandleTypeDef *htim, uint32_t Channel, uint16_t pulse,uint16_t period) 
{
	__HAL_TIM_SET_COMPARE(htim, Channel, pulse);
	__HAL_TIM_SET_AUTORELOAD(htim, period);  
}





