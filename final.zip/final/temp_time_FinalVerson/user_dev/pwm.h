/**
 * @file   pwm.h
 * @brief  基于CUBE的pwm驱动程序
 * @author 王晓荣
 * @version 
 * @date 2019-04-09
 */
 
#ifndef __PWM_H
#define __PWM_H

#include "stm32f0xx_hal.h"              // Keil.Standalone::Device:STM32Cube HAL:COMMON
#include "stm32f0xx_hal_tim.h"


#define PWM_1 &htim1, TIM_CHANNEL_1

void pwm_start(TIM_HandleTypeDef *htim, uint32_t Channel);
void pwm_stop(TIM_HandleTypeDef *htim, uint32_t Channel);
void pwm_set_period(TIM_HandleTypeDef *htim, uint32_t Channel, uint16_t period);
void pwm_set_compare(TIM_HandleTypeDef *htim, uint32_t Channel, uint16_t pulse);
void pwm_set_compare_period(TIM_HandleTypeDef *htim, uint32_t Channel, uint16_t pulse,uint16_t period);
#endif 
