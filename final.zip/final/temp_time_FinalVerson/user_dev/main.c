/**
 * @file     main.c
 * @brief    在“led_v1.0”基础上，添加led模块，实现LED闪烁
 *					 LED引脚：GPIOA.8 GPIOD.2  GPIOC.12
 * @author   王晓荣
 * @version 
 * @date     2019-03-12
 */ 

#include "led.h"

int main(void)
{
  led_config();
  led_off(LED_ALL);	
	
	while(1)
	{
		led_toggle(LED_0);
		for(int i = 0; i < 500000; i++); 		 
	}
}



  
