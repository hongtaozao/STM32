/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "led.h"
#include "key.h"
#include "digitron.h"
#include "usart.h"
#include "uart_buffer.h"
#include "ad_buffer.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
	struct TIME 
	{
		int year;
		int month;
		int day;
		int hour;
		int min;
		int sec;
	} TimeOnScr,TimeForSet;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
	
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
		enum Mode			//**	enum mode is used to classify different screen	*/
		{
			SCR_Temp,
			SCR_HourMin,
			SCR_Sec,
			SCR_SET_Hour,
			SCR_SET_Min,
			SCR_SET_Sec,
			SCR_Date,
			}mode;
		enum Recv_Mode
		{
			Recv_HourMinSec,
			Recv_HourMinSec_NoSign,
			Recv_HourOnly,
			Recv_MinOnly,
			Recv_SecOnly,
			Recv_SecZero,
			Recv_YearOnly,
			Recv_MonthOnly,
			Recv_DayOnly,
			Recv_YearMonthDay,
			Recv_ErrorData,
			Recv_Help,
		} recv_mode;
		float temp_print;
		enum KEY key = NO_PRESS;
		int temp_BeforDot,temp_AfterDot;		//**	these two variable is used to display temperature in digitron	*/
		uint16_t ad_value[ADC_CHANNEL_NUMB];
		static struct UART_CTRL* p_uart_ctrl;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
enum Mode choose_mode(void);			//** this function is used to response key action and select mode	*/
void screen_ModeDisplay(enum Mode mode);			//**	this function is used to display different screen	*/
uint8_t *put_array(void);
void set_time(uint8_t *a);
enum Recv_Mode Choose_RecvMode(uint8_t *a);
void time_caculate(void);
void Recv(uint8_t *a);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static int MonthMap[] =
{
	29,		//** <run yue*/
	31,		28,		31,		30,			//**	month 1~4	*/
	31,		30,		31,		31,			//**	month 5~8	*/
	30,		31,		30,		31,			//**	month 9-12	*/
};
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM6_Init();
  MX_USART1_UART_Init();
  MX_ADC_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim6);
  uart_init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	uint8_t array[30]; 
	TimeOnScr.hour = TimeOnScr.min = TimeOnScr.sec = 0;
	TimeOnScr.month = TimeOnScr.day = 1;
	TimeOnScr.year = 2000;
	led_off(LED_ALL);
	adc_dma_start();
	mode = SCR_Temp;
  p_uart_ctrl = get_p_uart_ctrl();
  while (1)
  {
	mode= choose_mode();
	screen_ModeDisplay(mode);
	Recv(array);
	time_caculate();
	set_time(array);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI14|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void Recv(uint8_t *a)
{
	
	if(p_uart_ctrl->recv_end_flg)
    {
      for(int i = 0; i < p_uart_ctrl->rx_len; i++)
      {
				a[i] = p_uart_ctrl -> rx_buf[i];
      }
			clr_rx_buf();    
      p_uart_ctrl->rx_len       = 0;
      p_uart_ctrl->recv_end_flg = 0;           
    }
    uart_buf_receive_dma();
		HAL_Delay(1);

}
void time_caculate(void)
{
	if(TimeOnScr.sec >= 60)
	{
		TimeOnScr.sec = 0;
		TimeOnScr.min += 1;
	}
	if(TimeOnScr.min >= 60)
	{
		TimeOnScr.min = 0;
		TimeOnScr.hour += 1;
	}
	if(TimeOnScr.hour >= 24)
	{
		TimeOnScr.hour = 0;
		TimeOnScr.day += 1;
	}
	for(int i = 1 ; i <= 12 ; i++)
	{
		if(TimeOnScr.month == i)
		{
			if(TimeOnScr.day > MonthMap[i])
			{
				TimeOnScr.day = 1;
				TimeOnScr.month += 1;
			}
//			if(TimeOnScr.day <= MonthMap[i]) TimeOnScr.day += 1;
		}
		if(TimeOnScr.month > 12)
		{
			TimeOnScr.year += 1;
			TimeOnScr.month = 1;
		}
		if(TimeOnScr.year % 4 == 0 && TimeOnScr.year % 100 != 0) MonthMap[2] = 29;
		else MonthMap[2] = 28;
	} 
}
enum Recv_Mode Choose_RecvMode(uint8_t *a)			
{
	int Hour_Bit_Recv,Min_Bit_Recv,Month_Bit_Recv;
	//**	if Recv_Mode is time:xx.xx.xx# or time:xx.xx#	*/
	if(a[0]=='t'&&a[1]=='i'&&a[2]=='m'&&a[3]=='e'&&a[4]==':')
	{
		if(a[6]=='.') 
		{
			TimeForSet.hour = (int)(a[5]-'0');
			Hour_Bit_Recv = 1;
		}
		if(a[7]=='.')
		{
			TimeForSet.hour = (a[5]-'0')*10+a[6]-'0';
			Hour_Bit_Recv = 2;
		}
		if(a[7+Hour_Bit_Recv]=='.')
		{
			TimeForSet.min = a[6+Hour_Bit_Recv]-'0';
			Min_Bit_Recv = 1;
		}
		if(a[8+Hour_Bit_Recv]=='.')
		{
			TimeForSet.min = (a[6+Hour_Bit_Recv]-'0')*10 + a[7+Hour_Bit_Recv]-'0';
			Min_Bit_Recv = 2;
		}
		if(a[8+Hour_Bit_Recv+Min_Bit_Recv]=='#')
		{
			TimeForSet.sec = a[7+Hour_Bit_Recv+Min_Bit_Recv]-'0';
		}
		if(a[9+Hour_Bit_Recv+Min_Bit_Recv] == '#')
		{
			TimeForSet.sec = (a[7+Hour_Bit_Recv+Min_Bit_Recv]-'0')*10 + a[8+Hour_Bit_Recv+Min_Bit_Recv]-'0';
		}
		if(a[7+Hour_Bit_Recv]=='#')
		{
			TimeForSet.min = a[6+Hour_Bit_Recv]-'0';
			TimeForSet.sec = 0;
		}
		if(a[8+Hour_Bit_Recv]=='#')
		{
			TimeForSet.min = (a[6+Hour_Bit_Recv]-'0')*10 + a[7+Hour_Bit_Recv]-'0';
			TimeForSet.sec = 0;
		}
		if(TimeForSet.hour >= 0 && TimeForSet.hour<=23 && TimeForSet.min >= 0 && TimeForSet.min <= 59 && TimeForSet.sec >= 0 && TimeForSet.sec <= 59) return Recv_HourMinSec;
		else return Recv_ErrorData;
}
	
//**	if Recv_Mode is hour:xx#	*/
	else if(a[0]=='h' && a[1]=='o' && a[2]=='u' && a[3]=='r' && a[4]==':')
	{
		if(a[6]=='#')
		{
			TimeForSet.hour = (int)(a[5]-'0');
		}
		if(a[7]=='#')
		{
			TimeForSet.hour = (a[5]-'0')*10+a[6]-'0';
		}
		if(TimeForSet.hour >= 0 && TimeForSet.hour <= 23) return Recv_HourOnly;
		else return Recv_ErrorData;
	}
	
//**	if Recv_Mode is min:xx#	*/
	else if(a[0]=='m' && a[1]=='i' && a[2]=='n' && a[3]==':')
	{
		if(a[5]=='#')
		{
			TimeForSet.min = (int)(a[4]-'0');
		}
		if(a[6]=='#')
		{
			TimeForSet.min = (a[4]-'0')*10+a[5]-'0';
		}
		if(TimeForSet.min >= 0 && TimeForSet.min <= 59) return Recv_MinOnly;
		else return Recv_ErrorData;
	}
	
//**	if Recv_Mode is sec:xx#	*/
	else if(a[0]=='s' && a[1]=='e' && a[2]=='c' && a[3]==':')
	{
		if(a[5]=='#')
		{
			TimeForSet.sec = a[5]-'0';
		}
		if(a[6]=='#')
		{
			TimeForSet.sec = (a[4]-'0')*10+a[5]-'0';
		}
		if(TimeForSet.sec >= 0 && TimeForSet.sec <= 59) return Recv_SecOnly;
		else return Recv_ErrorData;
	}
	
//**	if Recv_Mode is sec_zero#	*/
	else if(a[0]=='s' && a[1]=='e' && a[2]=='c' && a[3]=='_' && a[4]=='z' && a[5]=='e' && a[6]=='r' && a[7]=='o' && a[8]=='#')
	{
		return Recv_SecZero;
	}
	
	//**	if Recv_Mode contain help	*/
	else if(a[0]=='h' && a[1]=='e' && a[2]=='l' && a[3]=='p') return Recv_Help;
	else if(a[0]=='y' && a[1]=='e' && a[2]=='a' && a[3]=='r' && a[4]==':')
	{
		TimeForSet.year = (a[5]-'0')*1000 + (a[6]-'0')*100 + (a[7]-'0')*10 + a[8]-'0';
		if(TimeForSet.year >= 0 && TimeForSet.year<=9999) return Recv_YearOnly;
	}
	
	else if(a[0]=='m' && a[1]=='o' && a[2]=='n' && a[3]=='t' && a[4]=='h' && a[5]==':' )
	{
		if(a[8]=='#')
		{
			TimeForSet.month = (a[6]-'0')*10 + a[7]-'0';
		}
		if(a[7]=='#')
		{
			TimeForSet.month = a[6]-'0';
		}
		if(TimeForSet.month >= 1 && TimeForSet.month <= 12) return Recv_MonthOnly;
	}
	
	else if(a[0]=='d' && a[1]=='a' && a[2]=='y' && a[3]==':')
	{
		if(a[6]=='#')
		{
			TimeForSet.day = (a[4]-'0')*10 + a[5]-'0';
		}
		if(a[5]=='#')
		{
			TimeForSet.day = a[4]-'0';
		}
		if(TimeForSet.day >= 1 && TimeForSet.day <= MonthMap[TimeOnScr.month]) return Recv_DayOnly;
	}
	
	if(a[0]=='d' && a[1]=='a' && a[2]=='t' && a[3]=='e' && a[4]==':')
	{
		if(a[9]=='.') 
		{
			TimeForSet.year = (a[5]-'0')*1000 + (a[6]-'0')*100 + (a[7]-'0')*10 + a[8]-'0';
		}
		if(a[11]=='.')
		{
			TimeForSet.month = a[10]-'0';
			Month_Bit_Recv = 1;
		}
		if(a[12]=='.')
		{
			TimeForSet.month = (a[10]-'0')*10 + a[11]-'0';
			Month_Bit_Recv = 2;
		}
		if(a[13+Month_Bit_Recv]=='#')
		{
			TimeForSet.day = (a[11+Month_Bit_Recv]-'0')*10 + a[12+Month_Bit_Recv]-'0';
		}
		if(a[12+Month_Bit_Recv] == '#')
		{
			TimeForSet.day = a[11+Month_Bit_Recv]-'0';
		}
		
		if(TimeForSet.year > 0 && TimeForSet.year<=9999 && TimeForSet.month >= 1 && TimeForSet.month <= 12 && TimeForSet.day >= 1 && TimeForSet.day <= MonthMap[TimeForSet.month]) return Recv_YearMonthDay;
		else return Recv_ErrorData;
}
}


void set_time(uint8_t *a)
{
	enum Recv_Mode R;
	uint8_t *h=a;
	R = Choose_RecvMode(h);
	
	//**	receive time:xx.xx.xx# or time:xx.xx#	*/
	if(R == Recv_HourMinSec)
		{
			TimeOnScr.hour = TimeForSet.hour;
			TimeOnScr.min = TimeForSet.min;
			TimeOnScr.sec = TimeForSet.sec;
		}
		
		//**	if receive hour:xx#	*/
		if(R == Recv_HourOnly)
		{
			TimeOnScr.hour = TimeForSet.hour;
		}
		
		//**	if receive min:xx#	*/
		if(R == Recv_MinOnly)
		{
			TimeOnScr.min = TimeForSet.min;
		}
		
		//**	if receive sec:xx#	*/
		if(R == Recv_SecOnly)
		{
			TimeOnScr.sec = TimeForSet.sec;
		}
		
		//**	if receive sec_zero#	*/
		if(R == Recv_SecZero)
		{
			TimeOnScr.sec = 0;
		}
		
		//**	if format is wrong	*/
		if(R == Recv_ErrorData)
		{
			printf("please type in right format\n");
		}
		
		//**	if receive help	*/
		if(R == Recv_Help)
		{
			printf("you can set this clock with following methods:\n  1.type time:xx.xx.xx#\n  2.type time:xx.xx#\n  3.type in hour:xx# or min:xx# or sec:xx# or sec_zero#\n");
		}
		
		if(R == Recv_YearOnly)
		{
			TimeOnScr.year = TimeForSet.year;
		}
		
		if(R == Recv_MonthOnly)
		{
			TimeOnScr.month = TimeForSet.month;
		}
		
		if(R == Recv_DayOnly)
		{
			TimeOnScr.day = TimeForSet.day;
		}
		if(R == Recv_YearMonthDay)
		{
			TimeOnScr.year = TimeForSet.year;
			TimeOnScr.month = TimeForSet.month;
			TimeOnScr.day = TimeForSet.day;
		}
		for(int j=0;j<30;j++) a[j]=NULL;
}
	enum Mode choose_mode(void)
{
		key_read(&key);
		if(key == KEY_WKUP_LONG) {mode = SCR_Date ; key = NO_PRESS;}
		if(mode == SCR_Date && key == KEY_WKUP_SHORT) {mode = SCR_Temp ; key = NO_PRESS;}
		if(mode == SCR_Temp && key == KEY_WKUP_SHORT ) {mode = SCR_HourMin ; key = NO_PRESS;}
		if(mode == SCR_HourMin && key == KEY_WKUP_SHORT ) {mode = SCR_Sec ; key = NO_PRESS;}
		if(mode == SCR_Sec && key == KEY_WKUP_SHORT ) {mode = SCR_SET_Hour ; key = NO_PRESS;}
		if(mode == SCR_SET_Hour && key == KEY_WKUP_SHORT ) {mode = SCR_SET_Min ; key = NO_PRESS;}
		if(mode == SCR_SET_Min && key == KEY_WKUP_SHORT ) {mode = SCR_SET_Sec ; key = NO_PRESS;}
		if(mode == SCR_SET_Sec && key == KEY_WKUP_SHORT ) {mode = SCR_Temp ; key = NO_PRESS;}   
		return mode;
	}
void screen_ModeDisplay(enum Mode mode)
{
	led_off(LED_ALL);
	if(mode == SCR_Date)
	{
		digitron_put_data(0,2,TimeOnScr.day);
		digitron_put_data(2,2,TimeOnScr.month);
		digitron_put_dot(4);
		digitron_dynamic_display();
		led_on(LED_ALL);
	}
	if(mode == SCR_Temp)			//**	screen 1	*/
		{
			get_adc_value(&ad_value[0]);
			temp_print = ((float)ad_value[0]/4095)*10+25;
			temp_AfterDot = (int)(temp_print * 10) % 10;
			temp_BeforDot = (int)temp_print;
			digitron_put_data(1,1,temp_AfterDot);
			digitron_put_data(2,2,temp_BeforDot);
			digitron_put_buf(0,15);
			digitron_put_dot(4);
			digitron_dynamic_display();
			HAL_Delay(1);
		}
		if(mode == SCR_HourMin)			//**	srceen 2	*/
		{
			digitron_put_data(0,2,TimeOnScr.min);
			digitron_put_data(2,2,TimeOnScr.hour);
			if(TimeOnScr.sec%2 ==1) digitron_put_dot(4);
			else digitron_put_dot(0);
			digitron_dynamic_display();
		}
		if(mode ==SCR_Sec)			//**	screen 3	*/
		{
			digitron_put_dot(0);
			digitron_put_buf(3,10);
			digitron_put_buf(2,12);
			digitron_put_data(0,2,TimeOnScr.sec);
			digitron_dynamic_display();
		}
		if(mode == SCR_SET_Hour)			//**	screen 4	*/
		{
			led_on(LED_2);
			if(key == KEY_0_SHORT) TimeOnScr.hour += 1;
			if(key == KEY_1_SHORT) 
			{
				if(TimeOnScr.hour == 0) TimeOnScr.hour = 0;
				else TimeOnScr.hour -= 1;
			}
			digitron_put_buf(3,16);
			digitron_put_data(0,2,TimeOnScr.hour);
			digitron_put_buf(2,10);
			digitron_dynamic_display();
			led_on(LED_2);
		}
		if(mode == SCR_SET_Min)			//**	screen 5	*/
		{
			led_on(LED_0);
			if(key == KEY_0_SHORT) TimeOnScr.min += 1;
			if(key == KEY_1_SHORT)
			{
				if(TimeOnScr.min == 0) TimeOnScr.min = 0;
				else TimeOnScr.min-= 1;
			}
			digitron_put_buf(3,16);
			digitron_put_data(0,2,TimeOnScr.min);
			digitron_put_buf(2,10);
			digitron_dynamic_display();
			led_on(LED_0);
		}
		if(mode == SCR_SET_Sec)			//**	screen 6	*/
		{
			led_on(LED_1);
			if(key == KEY_0_LONG) TimeOnScr.sec = 30;
			if(key == KEY_1_LONG) TimeOnScr.sec = 0;
			if(key == KEY_0_SHORT) TimeOnScr.sec += 1;
			if(key == KEY_1_SHORT) 
			{
				if(TimeOnScr.min == 0) TimeOnScr.min = 0;
				else TimeOnScr.sec -= 1;
			}
			digitron_put_buf(3,16);
			digitron_put_data(0,2,TimeOnScr.sec);
			digitron_put_buf(2,10);
			digitron_dynamic_display();
			led_on(LED_1);
		}
}
/**
  * @brief  Period elapsed callback in non blocking mode 
  * @param  htim TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if(htim==&htim6)
	{
		TimeOnScr.sec += 1;
		printf("time is %d:%d:%d  %d.%d.%d",TimeOnScr.hour,TimeOnScr.min,TimeOnScr.sec,TimeOnScr.year,TimeOnScr.month,TimeOnScr.day);
		printf("\n");
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
